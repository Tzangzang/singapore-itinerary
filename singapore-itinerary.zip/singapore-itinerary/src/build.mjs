// Bọc file artifact (chỉ có phần thân) thành một trang HTML hoàn chỉnh cho Vercel.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const SRC = new URL('./singapore-trip.html', import.meta.url);
const OUT_DIR = new URL('../', import.meta.url);
const OUT = new URL('../index.html', import.meta.url);

const raw = readFileSync(SRC, 'utf8');

// Tách <title>, <link> fonts và <style> ra khỏi phần thân.
const title = raw.match(/<title>([\s\S]*?)<\/title>/)?.[1]?.trim() ?? 'Singapore 5 Ngày';
const fontLink = raw.match(/<link rel="stylesheet" href="https:\/\/fonts\.googleapis[^>]*>/)?.[0] ?? '';
const styleBlock = raw.match(/<style>[\s\S]*?<\/style>/)?.[0] ?? '';

const body = raw
  .replace(/<title>[\s\S]*?<\/title>/, '')
  .replace(/<link rel="stylesheet" href="https:\/\/fonts\.googleapis[^>]*>/, '')
  .replace(/<style>[\s\S]*?<\/style>/, '')
  .trim();

const description =
  'Lịch trình chi tiết 28/8–1/9 tại Singapore: trọn ngày Mandai với gấu trúc và safari đêm, ' +
  'Universal Studios mở màn bằng Minion Land, Harry Potter ở Sentosa, gợi ý quán ăn theo ngày, ' +
  'và kế hoạch tách sân bay T1/T3 ngày về.';

// Favicon emoji nhúng thẳng, không cần file ngoài.
const faviconSvg =
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">' +
  '<text x="50" y="78" font-size="82" text-anchor="middle">🦁</text>' +
  '</svg>';
const favicon = 'data:image/svg+xml,' + encodeURIComponent(faviconSvg);

const reset = `
  /* reset tối thiểu cho trang standalone */
  html,body{margin:0;padding:0;}
  img,svg,video{max-width:100%;height:auto;display:block;}
  h1,h2,h3,p,ul,ol,figure{margin:0;}
  ul,ol{padding:0;list-style-position:outside;}
  .callout ul,footer ul{list-style:disc;}
  button,input,select,textarea{font:inherit;color:inherit;}
`;

const html = `<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>${title}</title>
<meta name="description" content="${description}">
<meta property="og:type" content="website">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${description}">
<meta name="twitter:card" content="summary">
<link rel="icon" href="${favicon}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
${fontLink}
<style>${reset}</style>
${styleBlock}
</head>
<body>
${body}
</body>
</html>
`;

mkdirSync(OUT_DIR, { recursive: true });
writeFileSync(OUT, html, 'utf8');
console.log(`✓ index.html — ${(html.length / 1024).toFixed(1)} KB`);
