# Lịch trình Singapore · 28/8 – 1/9

Trang web tĩnh một file, không phụ thuộc thư viện ngoài (trừ Google Fonts).

## Đưa lên GitHub rồi nối vào Vercel

**Bước 1 — tạo repo trống trên GitHub.** Vào [github.com/new](https://github.com/new), đặt tên `singapore-itinerary`, chọn Public hoặc Private, **không** tick "Add a README" (repo này đã có sẵn), rồi bấm Create.

**Bước 2 — push code lên.** Giải nén thư mục này, mở terminal ngay trong đó và chạy:

```bash
git remote add origin https://github.com/<tên-github-của-bạn>/singapore-itinerary.git
git branch -M main
git push -u origin main
```

**Bước 3 — nối vào Vercel.** Vào [vercel.com/new](https://vercel.com/new), đăng nhập bằng chính tài khoản GitHub đó, chọn repo `singapore-itinerary` vừa push, rồi bấm **Deploy**. Không cần chỉnh gì trong phần cấu hình — Vercel tự nhận đây là trang tĩnh vì repo không có `package.json`.

Khoảng một phút sau bạn sẽ có link dạng `singapore-itinerary.vercel.app`.

Từ đó về sau, mỗi lần `git push` là Vercel tự deploy lại.

## Sửa nội dung

Nội dung nằm ở `index.html` — sửa thẳng file đó là được.

`src/` chỉ giữ bản gốc dùng cho Claude Artifact (`singapore-trip.html`, chỉ có phần thân, không có `<head>`) và script `build.mjs` bọc nó thành trang hoàn chỉnh. Nếu sửa bản gốc thay vì `index.html`, chạy lại:

```bash
cd src && node build.mjs
```

Script sẽ ghi đè `index.html` ở thư mục gốc.

## Cấu trúc

```
index.html      trang web (36 KB, đã gồm toàn bộ CSS)
vercel.json     cleanUrls + hai header bảo mật cơ bản
src/            bản gốc dạng artifact + script build
```
